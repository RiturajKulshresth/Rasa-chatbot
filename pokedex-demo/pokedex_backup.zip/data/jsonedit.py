import json
f=open("subset1.json","r")
data=json.load(f)

print(type(data))

for ele in data:
    print(ele["passages"])

a_file=open("edited.json","w")
json.dump(data,a_file)
f.close()
a_file.close()